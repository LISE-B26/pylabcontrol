from .basic_application_window import Ui_MainWindow
from .load_dialog import Ui_Dialog